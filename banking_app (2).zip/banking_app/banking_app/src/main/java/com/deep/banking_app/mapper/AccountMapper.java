package com.deep.banking_app.mapper;

import com.deep.banking_app.dto.AccountDto;
import com.deep.banking_app.entity.Account;
import com.deep.banking_app.service.AccountService;

public class AccountMapper {
    public static Account maptoAccount(AccountDto accountDto){
        Account account=new Account(
                accountDto.getId(),
                accountDto.getAccountholdername(),
                accountDto.getBalance()
        );
        return account;

    }
    public static AccountDto maptoAccountDto(Account account){
        AccountDto accountDto=new AccountDto(
                account.getId(),
                account.getAccountHolderName(),
                account.getBalance()
        );
        return accountDto;
    }
}
